package com.app.carShowroom.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.carShowroom.beans.Car;
import com.app.carShowroom.beans.User;
import com.app.carShowroom.database.DatabaseAccess;

@Controller

public class loginController {
	
	@Autowired
	private DatabaseAccess dataObj;
	
	/**Directs to home page of application
	 * @return A HTML page which acts as home page
	 */
	@PostMapping("/login")
	public String goHome(@RequestParam String email,@RequestParam String password,Model map )
	{     System.out.println(email+password);
	        Boolean b=dataObj.validateUser(email, password);
	        System.out.println("b="+b);
	       if(b==false) { 
	    	   System.out.println("inside if");
	    	   return "/home2.html";}
	       else {
	    	   map.addAttribute("car",new Car());
	    	   System.out.println("inside else");
	    	   return "/CustomerPage.html";}
	}
	@GetMapping("/register")
	public String registerPage(Model map)
	{
		map.addAttribute("user",new User());
		return "register.html";
	}
	@PostMapping("/register")
	public String addCar(@ModelAttribute User user)
	{    System.out.println(user);
		dataObj.addUser(user);
		return "home3.html";
	}
	
	
}
