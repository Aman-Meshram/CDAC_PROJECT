package com.app.carShowroom.beans;

public class User implements java.io.Serializable {
	
	
	private static final long serialVersionUID = 1L;
	private String emailId;
	private String fname;
	private String lname;
	private long contactnumber;
	private String password;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [emailId=" + emailId + ", fname=" + fname + ", lname=" + lname + ", contactnumber=" + contactnumber
				+ ", password=" + password + "]";
	}
	public static Object getModel() {
		// TODO Auto-generated method stub
		return null;
		
	}
    

}
