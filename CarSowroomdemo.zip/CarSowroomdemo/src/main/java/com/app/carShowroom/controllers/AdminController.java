package com.app.carShowroom.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.carShowroom.beans.Car;
import com.app.carShowroom.database.DatabaseAccess;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private DatabaseAccess dataObj;
	
	/**Directs to home page of application
	 * @return A HTML page which acts as home page
	 */
	@GetMapping("/home")
	public String goHome(Model model)
	{
		return "adminhome.html";
	}
	@PostMapping("/login")
	public String goHome(@RequestParam String email,@RequestParam String password ,Model map)
	{     System.out.println(email+password);
	        Boolean b=dataObj.validateAdmin(email, password);
	        System.out.println("b="+b);
	       if(b==false) { 
	    	   System.out.println("inside if");
	    	   return "adminhome2.html";}
	       else {
	    	   System.out.println("inside else");
	    	   map.addAttribute("car", new Car());
	    	   return "adminInterface.html";}
	}
	
}
